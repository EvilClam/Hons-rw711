#!/bin/sh
java  -jar tut4.jar
        
